# Study Quest Android project

This Android Studio project wraps the Study Quest Class 10 web app in a native Android WebView shell. The app is bundled locally and works offline. Study records are stored locally on the device.

## Build a downloadable APK with GitHub Actions
1. Create a new GitHub repository and upload all files from this project ZIP.
2. Open the repository's **Actions** tab.
3. Choose **Build Study Quest APK** and press **Run workflow** (or push to main/master).
4. After the workflow succeeds, open the run and download the `study-quest-debug-apk` artifact.
5. Extract that artifact ZIP to get `app-debug.apk`, then transfer it to your Android phone and install it. Android may ask you to allow installs from your file manager.

You can also open this folder in Android Studio and use **Build > Build APK(s)**.

## Important
This ZIP is Android project source, not a compiled APK. A build environment with Android SDK is required to compile the APK. The generated debug APK is for personal testing, not a Play Store release.
